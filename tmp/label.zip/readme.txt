fg, bg, category, pos(s)
One pos label is 4 values.
There may be more than one pos.

pos label: x, y, w, h
where (x, y) is top left corner, i.e., xmin and ymax
The origin is at TOP LEFT of the img.

alt label: xmin, ymin, xmax, ymax of the bbox.
The origin is at BOTTOM LEFT of the img.
